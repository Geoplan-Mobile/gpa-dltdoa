package kr.geoplan.android.lib.dltdoa;

import android.os.Build;
import android.ranging.DlTdoaMeasurement;
import android.ranging.RangingDevice;
import android.util.Pair;

import androidx.annotation.RequiresApi;

import java.util.List;

import kr.geoplan.android.lib.dltdoa.internal.positioning.DlRoundAccumulator;
import kr.geoplan.android.lib.dltdoa.internal.positioning.DlTdoaPositionerImpl;

/**
 * DL-TDoA Positioner — 라이브러리 공개 진입점(facade).
 *
 * <p>측정값을 <b>한 건씩</b> {@link #update(RangingDevice, DlTdoaMeasurement)} 으로 흘려보내면,
 * 내부 {@link DlRoundAccumulator} 가 블록(라운드) 단위로 묶고 완성된 라운드를
 * {@link DlTdoaPositionerImpl} 로 넘겨 (x, y, z) 좌표를 산출한다. 결과는 생성 시 전달한
 * {@link PositionCallback} 으로 통지된다.
 *
 * <p>실제 측위 비즈니스 로직은 {@code internal.positioning} 패키지의
 * {@link DlTdoaPositionerImpl} 에 은닉(난독화 대상)되어 있으며, 이 클래스는 얇은 위임만 수행한다.
 *
 * <p>UWB 세션({@code android.ranging}) 의 생성/수명주기는 이 라이브러리 책임이 아니다.
 * 호출자(세션 래퍼)가 단건 측정 콜백을 받을 때마다 {@link #update(RangingDevice, DlTdoaMeasurement)}
 * 를 호출하면 된다.
 *
 * <p>사용 순서:
 * <ol>
 * <li>{@link #DlTdoaPositioner(PositionCallback)} 로 생성</li>
 * <li>{@link #applyAnchorInfo(AnchorInfo)} 로 앵커 좌표 주입</li>
 * <li>(선택) {@link #setMinRssi(int)} 로 신호 임계값 조정</li>
 * <li>측정 단건마다 {@link #update(RangingDevice, DlTdoaMeasurement)} 호출</li>
 * <li>세션 재시작 등으로 라운드 상태를 비우려면 {@link #reset()}</li>
 * </ol>
 */
@RequiresApi(Build.VERSION_CODES.BAKLAVA + 1)
public final class DlTdoaPositioner {

    /** 측정 한 건씩 도착하는 콜백을 한 라운드 묶음으로 모은다. */
    private final DlRoundAccumulator accumulator = new DlRoundAccumulator();
    /** 완성된 라운드 묶음으로 (x, y, z) 산출. */
    private final DlTdoaPositionerImpl impl;

    /**
     * @param callback 측위 좌표/에러를 받을 콜백
     */
    public DlTdoaPositioner(PositionCallback callback) {
        this.impl = new DlTdoaPositionerImpl(callback);
    }

    /** 앵커 좌표 주입. {@link #update(RangingDevice, DlTdoaMeasurement)} 전에 호출. */
    public void applyAnchorInfo(AnchorInfo info) {
        impl.applyAnchorInfo(info);
    }

    /** 최소 RSSI 임계값 설정 (dBm). 기본 -90. 이보다 약한 앵커 측정값은 제외된다. */
    public void setMinRssi(int minRssi) {
        impl.setMinRssi(minRssi);
    }

    /**
     * 측정 한 건 입력. 내부에서 라운드 누적을 수행하고, 라운드가 완성되면 좌표를 산출해
     * {@link PositionCallback#onPosition(double, double, double)} 를 호출한다.
     *
     * @param peer 측정 출처 디바이스(앵커)
     * @param m    DL-TDoA 단건 측정값
     */
    public void update(RangingDevice peer, DlTdoaMeasurement m) {
        List<Pair<RangingDevice, DlTdoaMeasurement>> ready = accumulator.add(peer, m);
        if (ready != null) {
            impl.update(ready);
        }
    }

    /** 누적 중인 라운드 상태를 비운다. 세션 중지/재시작 시 호출. */
    public void reset() {
        accumulator.reset();
    }
}
