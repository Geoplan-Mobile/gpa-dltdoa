package kr.geoplan.android.lib.dltdoa;

/**
 * DL-TDoA 측위 결과 콜백.
 *
 * <p>iOS 의 {@code DlTdoaSession.onPosition} / {@code onInvalidated} 와 동일한 역할.
 * Activity 또는 외부 모듈이 이 인터페이스를 구현해 측위 좌표/에러를 받는다.
 */
public interface PositionCallback {

    /**
     * 측위 좌표 갱신 시 호출.
     * @param x   x 좌표 (m)
     * @param y   y 좌표 (m)
     * @param z   z 좌표 (m). DL-TDoA Observer 가 제공하지 않으면 {@code Double.NaN}
     */
    void onPosition(double x, double y, double z);

    /**
     * 세션이 복구 불가능하게 종료된 경우 호출 (UWB 비활성, 시스템 invalidation 등).
     * @param error 사람이 읽을 수 있는 에러 메시지
     */
    void onInvalidated(String error);
}
