package kr.geoplan.android.lib.dltdoa;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * DL-TDoA 앵커 셋업 정보.
 *
 * <p>Edge {@code anchor_info} JSON 스키마:
 * <pre>
 * {
 *   "sessionId": Int,
 *   "anchors": [
 *     { "mac": "5555" (hex), "location": [x, y, z], "offsetNs": Double }, ...
 *   ]
 * }
 * </pre>
 *
 * <p>{@code offsetNs} 는 캘리브레이션 오프셋. Android 신 {@code android.ranging} API 는
 * {@code responderReplyTime} 기반 보정이 가능해 현재는 사용하지 않음.
 * 형식 호환 위해 파싱은 유지하되 단위 변환 없이 ns 원본 그대로 보관.
 */
public class AnchorInfo {

    /** DL-TDoA 세션 ID 기본값 (sample / Edge anchor_info 와 동일). */
    public static final int DEFAULT_SESSION_ID = 4444;

    /** Edge 가 알려준 sessionId. */
    public final int sessionId;
    /** 앵커 MAC(16-bit) → 좌표 [x, y, z] (m). */
    public final Map<Integer, double[]> coordinates;
    /// 앵커 MAC(16-bit) → offset (나노초, JSON 원본 그대로). 현재 측위 로직에서 사용 X.
    public final Map<Integer, Double> offsetNs;

    public AnchorInfo(int sessionId,
                      Map<Integer, double[]> coordinates,
                      Map<Integer, Double> offsetNs) {
        this.sessionId = sessionId;
        this.coordinates = coordinates;
        this.offsetNs = offsetNs;
    }

    /**
     * Edge {@code anchor_info} JSON 파싱.
     *
     * @return 파싱 성공 시 {@link AnchorInfo}, 실패 시 {@code null}.
     */
    public static AnchorInfo fromJson(String json) {
        try {
            JSONObject root = new JSONObject(json);
            int sessionId = root.optInt("sessionId", DEFAULT_SESSION_ID);
            JSONArray anchors = root.optJSONArray("anchors");
            Map<Integer, double[]> coords = new HashMap<>();
            Map<Integer, Double> offsets = new HashMap<>();
            if (anchors != null) {
                for (int i = 0; i < anchors.length(); i++) {
                    JSONObject a = anchors.getJSONObject(i);
                    String macStr = a.optString("mac", "");
                    if (macStr.isEmpty()) continue;
                    int mac;
                    try {
                        mac = Integer.parseInt(macStr, 16);
                    } catch (NumberFormatException e) {
                        continue;
                    }
                    JSONArray loc = a.optJSONArray("location");
                    if (loc == null || loc.length() < 3) continue;
                    double[] xyz = new double[]{
                            loc.optDouble(0, 0),
                            loc.optDouble(1, 0),
                            loc.optDouble(2, 0)
                    };
                    coords.put(mac, xyz);
                    offsets.put(mac, a.optDouble("offsetNs", 0.0));
                }
            }
            return new AnchorInfo(sessionId, coords, offsets);
        } catch (JSONException e) {
            return null;
        }
    }
}
